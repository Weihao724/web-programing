tool/language
fontend:
language: html, css, js
tool: fetch api, json


beckend:
language: js
tool: 
    json
    ejs- template engine that can render page dynamically from server side.
    use data from tmdb to generate html page dyanmically on web server.
    express- a ligth weight web server nodejs framework
    axios- a lib for send http request from server side. works the same way as the fetch api.
    cookies- used to preserve the user login status
    tmdb- the third party db that store movies and tvs data. it can be accessed with api by using axios. 


reference:
    https://www.w3schools.com/howto/howto_js_slideshow.asp
    https://developers.themoviedb.org/3/getting-started
    https://www.w3schools.com/css/css3_animations.asp
    http://expressjs.com/en/resources/middleware/cookie-parser.html

