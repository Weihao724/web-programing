function search() {
    let keyword = document.getElementById('keyword').value
    let category = document.getElementById('category').value

    if (keyword === "") {
        return alert("keyword can't be empty")
    }

    if (category === "")
        return alert("Category can't be empty")

    fetch(`/api/search?category=${category}&query=${keyword}`)
        .then(response => response.json())
        .then(data => {
            renderList(data.results)
        })
}

function clearForm() {
    document.getElementById('keyword').value = ""
    document.getElementById('category').value = ""
}

async function renderList(data) {
    let result = document.getElementById('results');
    let htmlStr = "";
    // result.innerHTML = '<h3>Loading.....</h3>'
    htmlStr = '<p>Showing results...</p>'
    htmlStr += data.map(el => {
        let category = el.title ? 'movie' : 'tv';
        let image_url = el.poster_path ? el.poster_path : 'https://cinemaone.net/images/movie_placeholder.png'
        let title = el.title || el.name;
        let year = el.year;
        let vote_average = el.vote_average;
        let vote_count = el.vote_count;
        let genres_str = el.genres_str;

        return `<div class="card">
        <img width="185" src="${image_url}" alt="">
        <div class="card-body">
            <h3>${title}</h3>
            <p style="font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;">
            <div>${year} | ${genres_str}</div>
            <div><span style="color: #ff5722;">&#9733; ${vote_average}/5</span>  ${vote_count} votes</div>
            </p>
            <p class="overview">
                ${el.overview}
            </p>
            <a href="/details/${category}/${el.id}">Read More</a>
        </div>
    </div>`
    }).join("");
    result.innerHTML = htmlStr;
}