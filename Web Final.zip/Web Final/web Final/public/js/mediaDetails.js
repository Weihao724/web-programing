
async function showCastDetail(event) {
    let id = event.target.dataset.id;
    let type = event.target.dataset.name;
    let response = await fetch(`/api/person/${id}`)
    let person = await response.json();
    person = person.results;
    let detailsNode = document.getElementById("modal");
    let htmlStr = ''
    let image_url = person.profile_path ? 'https://image.tmdb.org/t/p/w780' + person.profile_path : '/static/placeholder1.jpeg'
    htmlStr += `<div class="profile-l"><img style="width:100%" src="${image_url}" alt="${person.name}"></div>`
    htmlStr += `<div class="profile-r">
                     <h2>${person.name}</h2>
                     <p><b>GENDER</b>: ${person.gender == 1 ? 'Famale' : 'Male'}</p>
                     <p><b>BIRTH DAY</b>: ${person.birthday}</p>
                     
                     <p><b>BIRTH PLACE</b>: ${person.place_of_birth}</p>
                     <p><b>KNOWN FOR</b>: ${person.known_for_department}</p>
                     
                </div>`
    htmlStr += `<div>
                <h3>Biography</h3>
                <p><small>${person.biography}</small></p>
                </div>`;

    detailsNode.innerHTML = htmlStr;
    showOverlay(event);
}


function hideOverlay(ev) {
    ev.preventDefault();
    if (ev.target.dataset.message) {
        console.log(ev.target.dataset.message)
    } else {
        console.log("overlay")
    }

    let overlay = document.querySelector(".overlay");
    overlay.classList.remove('show');
    overlay.classList.add('hide');
    hideModal(ev)
}

function showOverlay(ev) {

    ev.preventDefault();
    let overlay = document.querySelector(".overlay");
    overlay.classList.remove('hide');
    overlay.classList.add('show');
    showModal(ev)
}

function showModal(ev) {
    ev.preventDefault();
    let model = document.querySelector(".modal");
    model.classList.remove('off');
    model.classList.add('on');
}

function hideModal(ev) {
    ev.preventDefault();
    let model = document.querySelector(".modal");
    model.classList.remove('on');
    model.classList.add('off');
}


async function addToFavorate() {
    params = window.location.pathname.split("/");
    let item = params.pop();
    let type = params.pop();
    let response = await fetch(`/api/details/${type}/${item}`)
    item = await response.json();
    if (!localStorage.getItem('favorate')) {
        localStorage.setItem('favorate', JSON.stringify([]));
    }
    let favorate = JSON.parse(localStorage.getItem('favorate'));
    favorate.push(item);
    localStorage.setItem('favorate', JSON.stringify(favorate))
    document.getElementById("add").style.display = 'none';
    document.getElementById("remove").style.display = 'block';
    showMessage('Added to favorate list')
}

function removeFromFavorate() {

    let id = window.location.pathname.split("/").pop()
    if (!localStorage.getItem('favorate')) {
        localStorage.setItem('favorate', JSON.stringify([]));
    }
    let favorate = JSON.parse(localStorage.getItem('favorate'));
    favorate = favorate.filter((i) => id != i.id)
    localStorage.setItem('favorate', JSON.stringify(favorate))
    document.getElementById("add").style.display = 'block';
    document.getElementById("remove").style.display = 'none';
    showMessage('Removed from favorate list')
}

function isFavorate() {
    let id = window.location.pathname.split("/").pop()
    if (!localStorage.getItem('favorate')) {
        localStorage.setItem('favorate', JSON.stringify([]));
    }
    let favorate = JSON.parse(localStorage.getItem('favorate'));
    return !!(favorate.find((i) => id == i.id))
}

function showMessage(msg) {
    document.getElementById('msg').style.display = 'block';
    document.getElementById('msg').textContent = msg;
    setTimeout(() => {
        document.getElementById('msg').style.display = 'none';
    }, 2000)
}

window.addEventListener('DOMContentLoaded', () => {

    if (isFavorate()) {
        document.getElementById("add").style.display = 'none';
    } else {
        document.getElementById("remove").style.display = 'none';
    }
    document.getElementById('msg').style.display = 'none';
    document.querySelector(".close").addEventListener("click", hideOverlay)
    document.querySelector(".overlay").addEventListener("click", hideOverlay)
    document.getElementById("add").addEventListener("click", addToFavorate)
    document.getElementById("remove").addEventListener("click", removeFromFavorate)

})